<?php

return [
    App\Providers\AppServiceProvider::class,
    'LaravelPWA' => \Ladumor\LaravelPwa\PWAServiceProvider::class,
];
